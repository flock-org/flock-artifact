package main

import (
	"encoding/hex"
	"log"
	"math/big"
	"net/http"
	"os"
	"strconv"

	"github.com/daryakaviani/on-demand-dots/internal/networking"
	"github.com/daryakaviani/on-demand-dots/internal/signing"
	"github.com/gin-gonic/gin"
)

func getSignature(c *gin.Context) {
	EC2Addr := c.Param("ec2Addr")
	NumParties := c.Param("numParties")
	Party := c.Param("party")
	EC2Port := c.Param("ec2Port")
	EncKey := c.Param("encKey")
	Threshold := c.Param("threshold")
	Message := c.Param("message")
	Username := c.Param("username")

	NumPartiesInt, err := strconv.Atoi(NumParties)
	if err != nil {
		log.Printf("Error converting NumParties to int: %v\n", err)
		return
	}

	PartyInt, err := strconv.Atoi(Party)
	if err != nil {
		log.Printf("Error converting Party to int: %v\n", err)
		return
	}

	EC2PortInt, err := strconv.Atoi(EC2Port)
	if err != nil {
		log.Printf("Error converting EC2Port to int: %v\n", err)
		return
	}

	ThresholdInt, err := strconv.Atoi(Threshold)
	if err != nil {
		log.Printf("Error converting Threshold to int: %v\n", err)
		return
	}

	MessageInt, err := strconv.Atoi(Message)
	if err != nil {
		log.Printf("Error converting Message to int: %v\n", err)
		return
	}

	encKey, _ := hex.DecodeString(EncKey)
	comm := networking.RedisComm{Rank: PartyInt, PartySize: NumPartiesInt, EncKey: encKey, Username: Username}
	comm.Connect(EC2Addr, EC2PortInt)
	key := signing.KeyGenParty(PartyInt, NumPartiesInt, ThresholdInt, comm)
	signature := signing.SigningParty(PartyInt, NumPartiesInt, ThresholdInt, comm, key, big.NewInt(int64(MessageInt)))
	c.IndentedJSON(http.StatusOK, signature)
}

func get_port() string {
	port := ":8080"
	if val, ok := os.LookupEnv("FUNCTIONS_CUSTOMHANDLER_PORT"); ok {
		port = ":" + val
	}
	return port
}

func main() {
	r := gin.Default()
	r.GET("/api/sign/:ec2Addr/:numParties/:party/:ec2Port/:encKey/:threshold/:message:/username", getSignature)
	r.Run(get_port())
}
