package serverless

import (
	"bytes"
	"context"
	"encoding/hex"
	"encoding/json"
	"io/ioutil"
	"log"
	"math/big"

	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/aws/awserr"
	"github.com/aws/aws-sdk-go/aws/session"
	"github.com/aws/aws-sdk-go/service/lambda"
	"github.com/daryakaviani/on-demand-dots/internal/networking"
	"github.com/daryakaviani/on-demand-dots/internal/signing"

	"github.com/aws/aws-lambda-go/events"
)

type ServerEvent struct {
	EC2Addr    string `json:"ec2Addr"`
	EC2Port    int    `json:"ec2Port"`
	PartyInt   int    `json:"partyInt"`
	NumParties int    `json:"numParties"`
	Threshold  int    `json:"threshold"`
	Message    int    `json:"message"`
	TCPPunch   bool   `json:"tcpPunch"`
	EncKey     string `json:"encKey"`
	Username   string `json:"username"`
}

// Creates a socket using TCP hole punching. If sender client, sends a message
// via the socket. Otherwise, listens and receives a message.
func LambdaHandler(ctx context.Context, input ServerEvent) (events.APIGatewayProxyResponse, error) {
	encKey, _ := hex.DecodeString(input.EncKey)
	comm := networking.RedisComm{Rank: input.PartyInt, PartySize: input.NumParties, EncKey: encKey, Username: input.Username}
	comm.Connect(input.EC2Addr, input.EC2Port)
	key := signing.KeyGenParty(input.PartyInt, input.NumParties, input.Threshold, comm)
	signature := signing.SigningParty(input.PartyInt, input.NumParties, input.Threshold, comm, key, big.NewInt(int64(input.Message)))
	return events.APIGatewayProxyResponse{
		StatusCode: 200,
		Body:       signature,
	}, nil
}

func InvokeLambda(region string, ip string, port int, partyInt int, numParties int, numThreshold int, message int, tcpPunch bool, encKey string, username string) {
	sess, err := session.NewSession(&aws.Config{Region: aws.String(region)})
	if err != nil {
		log.Fatalf("Could not create new session: %v\n", err)
	}

	// create an AWS Lambda service client
	svc := lambda.New(sess)

	_, err = svc.GetFunction(&lambda.GetFunctionInput{FunctionName: aws.String("signing")})
	if err != nil {
		// check if the error is due to the function not existing
		if aerr, ok := err.(awserr.Error); ok && aerr.Code() == lambda.ErrCodeResourceNotFoundException {
			// deploy the function
			log.Fatal("Function does not exist. Please deploy first.")
		} else {
			log.Fatalf("Could not check for existence of function: %v\n", err)
		}
	} else {
		log.Printf("Invoking...")
	}

	event := map[string]interface{}{
		"ec2Addr":    ip,
		"ec2Port":    port,
		"partyInt":   partyInt,
		"numParties": numParties,
		"threshold":  numThreshold,
		"message":    message,
		"tcpPunch":   tcpPunch,
		"encKey":     encKey,
		"username":   username,
	}
	payload, _ := json.Marshal(event)

	input := &lambda.InvokeInput{
		FunctionName:   aws.String("signing"),
		InvocationType: aws.String("RequestResponse"),
		Payload:        payload,
	}

	result, err := svc.Invoke(input)
	if err != nil {
		log.Fatalf("Could not invoke signing: %v\n", err)
	}

	response, err := ioutil.ReadAll(bytes.NewReader(result.Payload))
	if err != nil {
		log.Fatalf("Could not read result of signing: %v\n", err)
	}

	log.Printf("%s", string(response))
}

func DeployLambda(region string) {
	sess, err := session.NewSession(&aws.Config{Region: aws.String(region)})
	if err != nil {
		log.Fatalf("Could not create new session: %v\n", err)
	}

	// create an AWS Lambda service client
	svc := lambda.New(sess)

	_, err = svc.GetFunction(&lambda.GetFunctionInput{FunctionName: aws.String("signing")})
	if err != nil {
		// check if the error is due to the function not existing
		if aerr, ok := err.(awserr.Error); ok && aerr.Code() == lambda.ErrCodeResourceNotFoundException {
			// deploy the function
			log.Print("Function is not found. Deploying...")
		} else {
			log.Fatalf("Could not check for existence of function: %v\n", err)
		}
	} else {
		log.Fatal("Function already exists.")
	}

	code, err := ioutil.ReadFile("aws-src.zip")
	if err != nil {
		log.Fatalf("Error reading file: %v\n", err)
	}
	// deploy the function
	// create the Lambda function
	_, err = svc.CreateFunction(&lambda.CreateFunctionInput{
		FunctionName: aws.String("signing"),
		Runtime:      aws.String("go1.x"),
		Role:         aws.String("arn:aws:iam::270448519663:role/service-role/testCommwithServer-role-0rr7ntvi"),
		Code: &lambda.FunctionCode{
			ZipFile: code,
		},
		Handler:    aws.String("main"),
		Timeout:    aws.Int64(900),
		MemorySize: aws.Int64(3008),
	})

	if err != nil {
		log.Fatalf("Failed to create function: %v\n", err)
	}

	log.Print("Function is deployed. You can invoke it now.")
}
