package serverless

import (
	"context"
	"encoding/hex"
	"fmt"
	"io/ioutil"
	"log"
	"math/big"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"

	"github.com/GoogleCloudPlatform/functions-framework-go/functions"
	"github.com/daryakaviani/on-demand-dots/internal/networking"
	"github.com/daryakaviani/on-demand-dots/internal/signing"
	"google.golang.org/api/cloudfunctions/v1"
	"google.golang.org/api/storage/v1"
)

func init() {
	functions.HTTP("GcpSign", GcpHandler)
}

func GcpHandler(w http.ResponseWriter, r *http.Request) {
	query := r.URL.Query()
	EC2Addr := query.Get("EC2Addr")
	NumParties := query.Get("NumParties")
	Party := query.Get("Party")
	EC2Port := query.Get("EC2Port")
	EncKey := query.Get("EncKey")
	Threshold := query.Get("Threshold")
	Message := query.Get("Message")
	Username := query.Get("Username")

	NumPartiesInt, err := strconv.Atoi(NumParties)
	if err != nil {
		log.Printf("Error converting NumParties to int: %v\n", err)
		return
	}

	PartyInt, err := strconv.Atoi(Party)
	if err != nil {
		log.Printf("Error converting Party to int: %v\n", err)
		return
	}

	EC2PortInt, err := strconv.Atoi(EC2Port)
	if err != nil {
		log.Printf("Error converting EC2Port to int: %v\n", err)
		return
	}

	ThresholdInt, err := strconv.Atoi(Threshold)
	if err != nil {
		log.Printf("Error converting Threshold to int: %v\n", err)
		return
	}

	MessageInt, err := strconv.Atoi(Message)
	if err != nil {
		log.Printf("Error converting Message to int: %v\n", err)
		return
	}

	var comm networking.RedisComm
	encKey, _ := hex.DecodeString(EncKey)
	comm = networking.RedisComm{Rank: PartyInt, PartySize: NumPartiesInt, EncKey: encKey, Username: Username}
	comm.Connect(EC2Addr, EC2PortInt)
	key := signing.KeyGenParty(PartyInt, NumPartiesInt, ThresholdInt, comm)
	signature := signing.SigningParty(PartyInt, NumPartiesInt, ThresholdInt, comm, key, big.NewInt(int64(MessageInt)))

	fmt.Fprint(w, signature)
}

func InvokeGoogleCloudFunction(region string, ip string, port string, partyInt string, numParties string, numThreshold string, message string, encKey string, username string) {
	// Execute the command to get the identity token
	output, err := exec.Command("gcloud", "auth", "print-identity-token").Output()
	if err != nil {
		log.Fatalf("Could not get identity token %v", err)
	}
	// Concatenate the string together
	authString := fmt.Sprintf("bearer %s", strings.TrimSpace(string(output)))

	client := &http.Client{}

	projectID := "on-demand-dots-375501"
	functionName := "signing-programatic"

	functionURL := fmt.Sprintf("https://%s-%s.cloudfunctions.net/%s", region, projectID, functionName)

	req, err := http.NewRequest("GET", functionURL, nil)
	if err != nil {
		log.Fatalf("%v", err)
	}

	query := req.URL.Query()
	query.Add("EC2Addr", ip)
	query.Add("NumParties", numParties)
	query.Add("Party", partyInt)
	query.Add("EC2Port", port)
	query.Add("EncKey", encKey)
	query.Add("Threshold", numThreshold)
	query.Add("Message", message)
	query.Add("Username", username)
	req.URL.RawQuery = query.Encode()

	// Add headers
	req.Header.Add("Content-Type", "application/json")
	req.Header.Add("Authorization", authString)

	resp, err := client.Do(req)
	if err != nil {
		log.Fatalf("%v", err)
	}

	body, _ := ioutil.ReadAll(resp.Body)
	signature := string(body)
	log.Print(signature)
}

func DeployGoogleCloudFunction(region string) {
	projectID := "on-demand-dots-375501"

	// create a new Cloud Functions service client
	svc, err := cloudfunctions.NewService(context.Background())
	if err != nil {
		log.Fatalf("Could not create new service client: %v\n", err)
	}

	sourceArchiveUrl := uploadCode()

	// create the Cloud Function
	_, err = svc.Projects.Locations.Functions.Create(fmt.Sprintf("projects/%s/locations/%s", projectID, region), &cloudfunctions.CloudFunction{
		Name:              fmt.Sprintf("projects/%s/locations/%s/functions/%s", projectID, region, "signing-programatic"),
		Runtime:           "go119",
		EntryPoint:        "GcpSign",
		Timeout:           "540s",
		AvailableMemoryMb: 8192,
		SourceArchiveUrl:  sourceArchiveUrl,
		HttpsTrigger: &cloudfunctions.HttpsTrigger{
			Url: "https://signing-programatic-hoqmg2noea-uc.a.run.app",
		},
	}).Do()
	if err != nil {
		log.Fatalf("Failed to create function: %v\n", err)
	}
	log.Print("Function created. You can invoke it now.")
}

func uploadCode() string {
	// create a new Storage service client
	storageService, err := storage.NewService(context.Background())
	if err != nil {
		log.Fatalf("Could not create new storage service client: %v\n", err)
	}

	// specify bucket name, and object name
	bucketName := "signing-bucket-on-demand-dots-375501"
	objectName := "gcp-src.zip"

	// get the absolute path of the source code file
	sourceCodePath, err := filepath.Abs(objectName)
	if err != nil {
		log.Fatalf("Failed to get the absolute path of the source code file: %v\n", err)
	}

	// open the source code file
	file, err := os.Open(sourceCodePath)
	if err != nil {
		log.Fatalf("Failed to open file: %v\n", err)
	}
	defer file.Close()

	// create the object
	object := &storage.Object{Name: objectName}
	_, err = storageService.Objects.Insert(bucketName, object).Media(file).Do()
	if err != nil {
		log.Fatalf("Failed to create object: %v\n", err)
	}
	fmt.Printf("File %v has been added to the bucket %v\n", objectName, bucketName)

	// create the source archive URL
	sourceArchiveUrl := fmt.Sprintf("gs://%s/%s", bucketName, objectName)
	fmt.Println("sourceArchiveUrl:", sourceArchiveUrl)

	// use the source archive URL to deploy the Cloud Function
	return sourceArchiveUrl
}
